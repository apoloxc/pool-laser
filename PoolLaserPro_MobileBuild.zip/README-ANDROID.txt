POOL LASER PRO — DEMO ANDROID

ESTA DESCARGA ES EL CÓDIGO FUENTE, NO UN APK LISTO PARA INSTALAR.

La demo permite:
- Mostrar una línea verde sobre otras aplicaciones (permiso de superposición).
- Girar manualmente la línea desde un panel flotante.
- Abrir 8 Ball Pool.

NO sigue automáticamente el taco ni detecta bolas. No automatiza golpes ni modifica el juego.

CÓMO GENERAR EL APK SOLO CON EL CELULAR:
1. Crea una cuenta gratuita en https://github.com/ desde el navegador.
2. En GitHub, crea un repositorio nuevo llamado PoolLaserPro.
3. Sube el contenido de este ZIP al repositorio (incluida la carpeta .github).
4. Abre la pestaña Actions del repositorio.
5. Selecciona "Build Android APK" y pulsa "Run workflow".
6. Cuando termine, abre la ejecución y descarga el artefacto "PoolLaserPro-debug".
7. Descomprime el artefacto y toca app-debug.apk para instalarlo.

Si GitHub muestra un error, comparte una captura para poder ayudarte.

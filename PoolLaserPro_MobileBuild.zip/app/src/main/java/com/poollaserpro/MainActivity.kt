package com.poollaserpro

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("POOL LASER PRO", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                    Text("Demo de mira flotante para Android")
                    Button(onClick = {
                        if (!Settings.canDrawOverlays(this@MainActivity)) {
                            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                        } else startService(Intent(this@MainActivity, OverlayService::class.java))
                    }, modifier = Modifier.fillMaxWidth()) { Text("ACTIVAR MIRA FLOTANTE") }
                    Button(onClick = { stopService(Intent(this@MainActivity, OverlayService::class.java)) }, modifier = Modifier.fillMaxWidth()) { Text("DETENER SUPERPOSICIÓN") }
                    Button(onClick = {
                        val game = packageManager.getLaunchIntentForPackage("com.miniclip.eightballpool")
                        if (game != null) startActivity(game)
                        else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.miniclip.eightballpool")))
                    }, modifier = Modifier.fillMaxWidth()) { Text("ABRIR 8 BALL POOL") }
                    Text("Esta demo dibuja una línea verde fija que se gira manualmente. No detecta automáticamente el taco ni las bolas y no automatiza golpes.")
                }
            }
        }
    }
}

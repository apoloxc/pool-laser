package com.poollaserpro

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.sin

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var guide: GuideView? = null
    private var panel: LinearLayout? = null
    private var angle = 0f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (guide == null) addGuide()
        if (panel == null) addPanel()
        return START_STICKY
    }

    private fun type() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun addGuide() {
        guide = GuideView()
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            type(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        wm.addView(guide, p)
    }

    private fun addPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 6, 8, 6)
            setBackgroundColor(0xDD17231C.toInt())
        }
        box.addView(TextView(this).apply { text = "POOL LASER"; setTextColor(Color.WHITE) })
        val row = LinearLayout(this)
        row.addView(Button(this).apply { text = "↶"; setOnClickListener { angle -= 3f; guide?.invalidate() } })
        row.addView(Button(this).apply { text = "↷"; setOnClickListener { angle += 3f; guide?.invalidate() } })
        box.addView(row)
        box.addView(Button(this).apply { text = "Cerrar"; setOnClickListener { stopSelf() } })
        panel = box
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.END
        p.x = 15; p.y = 140
        wm.addView(box, p)
    }

    inner class GuideView : View(this) {
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(70, 255, 150); strokeWidth = 5f }
        private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x6670FF96; strokeWidth = 15f }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width * .5f; val cy = height * .55f
            val a = Math.toRadians(angle.toDouble())
            val dx = cos(a).toFloat(); val dy = sin(a).toFloat()
            val r = maxOf(width, height) * 1.5f
            canvas.drawLine(cx-dx*r, cy-dy*r, cx+dx*r, cy+dy*r, glow)
            canvas.drawLine(cx-dx*r, cy-dy*r, cx+dx*r, cy+dy*r, line)
        }
    }

    override fun onDestroy() {
        guide?.let { runCatching { wm.removeView(it) } }
        panel?.let { runCatching { wm.removeView(it) } }
        guide = null; panel = null
        super.onDestroy()
    }
}
